#include <iostream>
#include <stdexcept> // for std::exception

// Custom exception derived from std::exception
class MyCustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "My custom exception message!";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard error
    throw std::runtime_error("Something went wrong!");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap function call in try/catch block to catch exceptions
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw the MyCustomException exception
    throw MyCustomException();

	std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0) {
        throw std::domain_error("Division by zero!"); // Use std::domain_error for division by zero
    }
    return (num / den);
}

void do_division() noexcept
{
    // Wrap entire function declaration in try/catch block to prevent unhandled division by 0 error
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& e) {
        std::cerr << "Caught division by zero exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
		do_custom_application_logic();
    }
    catch (const MyCustomException& e) {
        std::cerr << "Caught custom exception: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Caught std::exception: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Uncaught exception! Terminating program." << std::endl;
    }
}
